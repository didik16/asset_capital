<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asset Capital Holdings Limited</title>
    <meta name="description" content="Asset Capital Holdings Limited offers a wide range of investment solutions and advisory services to our clients" />
    <meta name="keywords" content="Hongkong Finance, Hongkong Wealth Management, Hongkong Investment, Hongkong IPO">
    <meta name="author" content="Asset Capital Holdings Limited">

    <meta property="og:site_name" content="https://assetcapitalholdingslimited.com.com" />
    <meta property="og:title" content="Asset Capital Holdings Limited" />
    <meta property="og:description" content="Asset Capital Holdings Limited offers a wide range of investment solutions and advisory services to our clients" />
    <meta property="og:image" content="../assets/images/fav.png" />
    <meta property="og:url" content="https://assetcapitalholdingslimited.com.com" />
    <meta property="og:type" content="website" />

    <link rel="stylesheet" href="assets/css/style.css" />

</head>

<body>
    <!-- Section Header -->
    <section id="header">
        <div class="header-img">
            <img src="assets/img/header.jpg">
        </div>
        <div class="header-text">
            <h3 class="opacFull">Asset Capital Holdings Limited offers a wide range of investment solutions and advisory services to our clients</h3>
        </div>
    </section>
    <!-- Section Header -->



</body>

</html>